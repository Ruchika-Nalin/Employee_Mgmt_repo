package com.artistTech.repository;1

import com.artistTech.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
t54

public interface EmployeeRepository extends JpaRepository<Integer , Employee> {
}
