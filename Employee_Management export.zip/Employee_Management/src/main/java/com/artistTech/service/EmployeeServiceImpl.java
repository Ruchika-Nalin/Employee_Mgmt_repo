package com.artistTech.service;

import com.artistTech.dto.EmployeeResponseDto;
import com.artistTech.dto.request.HealthCheckRequestDto;
import com.artistTech.dto.response.HealthCheckResponseDto;
import com.artistTech.entity.Employee;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl {

    public EmployeeResponseDto getAllEmployeeDetails(){

        return null;

    }


}
