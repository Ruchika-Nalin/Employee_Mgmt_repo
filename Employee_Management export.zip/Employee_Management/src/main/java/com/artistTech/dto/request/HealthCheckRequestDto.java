package com.artistTech.dto.request;

import lombok.Data;

@Data
public class HealthCheckRequestDto {
    private String applicationName;
}
